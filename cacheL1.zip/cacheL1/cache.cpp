/*********************************************************************************
 *********************************************************************************
 * Name: William Boyd, Dai Ho, Thao Tran
 * Date : 11/17/2017 FALL 2017
 * Course: ECE485
 * Final Project
 * File name: cache.cpp
 * Description: This file contains the definitions of the cache's member functions
 along with its constructor
 *********************************************************************************
 *********************************************************************************/

#include "cache.h"

/******************** CONSTRUCTOR & DESTRUCTOR ************************************/
cacheLine::cacheLine(void)
{
	address = NULL;
	tag = 0;
	mesiBit = 'I';	
}

//destructor
cacheLine::~cacheLine(void)
{
	delete address;
	address = NULL;
}

L1::L1(void)
{
	hit = 0;
	miss = 0;
	read = 0;
	write = 0;
	hitRate = 0;
};



/******************************* Read File *************************************/
int read_file(ifstream & filein, int & command, char * address)
{
	int end = 0;
	char to_get_address[SIZE];

	filein >> command;
	filein.ignore(100, ' ');

	if (!filein.eof())
	{
		filein.get(to_get_address, 100, '\n');
		filein.ignore(100, '\n');
		strcpy(address, to_get_address);
		end = 1;
	}
	
	return end;
}

