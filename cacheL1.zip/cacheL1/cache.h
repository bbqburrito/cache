/*********************************************************************************
 **********************************************************************************
 * Name: Thao Tran
 * Date : 11/17/2017 FALL 2017
 * Course: ECE485
 * Final Project
 * File name: cache.h
 * Description: This file contains the decription of cache class
 **********************************************************************************
 *********************************************************************************/

#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

const int iWays         = 2;            //I cache 2 ways associative
const int dWays         = 4;            //D cache 4 ways associative
const int numOfSets     = 16000;        //number of sets
const int sizeAddress   = 32;           //size of address
const int sizeLine      = 64;           //size of a cache line data
const int SIZE 			= 100;

//This struct contains content of a cache line
class cacheLine
{
public:
	cacheLine(void); //constructor
	~cacheLine(void); //destructor

private:
    char * address;
    int tag;
    char mesiBit;
};

//L1 cache
class L1
{
public:
    L1(void);  //constructor

    void readRequest(char * to_read_address);
    void writeRequest(char * to_write_address);
    void instructionFetch(char * to_fetch_address);
	void invalidatCommand(char * to_validate_address);
    void dataRequestFromL2(char * to_send_address);
    void clear(void);
    void print(void);
    
private:
	void updateLRU(int index);
    cacheLine iCache[numOfSets][iWays]; //instruction cache 16 sets, 2 ways
    cacheLine dCache[numOfSets][dWays]; //data cache 16 sets, 4 ways
	int hit;
	int miss;
	int read;
	int write;
	int hitRate;
};


/***********************************Other functions **********************************/
int read_file(ifstream & filein, int & command, char * address);
char * hexToBin(char * address);
int binToDecimal(char * bin);
int offsetCal(void);
int getIndex(char * address);
